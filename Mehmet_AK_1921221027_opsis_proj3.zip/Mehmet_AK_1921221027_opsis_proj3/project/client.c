

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

typedef struct sFileList
{
    char fileName[20];
} as;

as c_fileLİst[10];

int main()
{
    // pipe olusturmak icin.
    int fd;

    // pipe icin path
    char *myfifo = "/tmp/myfifo";
    mkfifo(myfifo, 0666);

    while (1)
    {

        // menu ekranı
        printf("** ISLEMLER **\n\n");
        printf("CREATE\n");
        printf("DELETE\n");
        printf("READ\n");
        printf("WRITE\n");
        printf("EXIT\n\n");
        printf("********\n\n\n");

        char str[80] = "";       // girilen islem tipini tutar
        char filename[80] = "";  // silinecek olusacak yazilacak okunacak dosya adını alir.
        char gelentext[80] = ""; // write'da yazilacak metini alir.

        printf("\n");
        printf("ISLEM GIRINIZ : ");
        gets(str);

        if (strcmp("EXIT", (str)) == 0)
        {
            printf("Cikis yapiliyor...\n");
            return 0;
        }
        else if (strcmp("CREATE", (str)) == 0)
        {
            // alinani pipe'a yazar.
            char gelenText[100];
            fd = open(myfifo, O_WRONLY);
            write(fd, str, strlen(str) + 1);
            close(fd);

            printf("\n");
            printf("Filename yaziniz :");
            gets(filename);
            // alinani pipe'a yazar.
            fd = open(myfifo, O_WRONLY);
            write(fd, filename, strlen(filename) + 1);
            close(fd);

            for (int i = 0; i < 10; i++)
            {
                if (c_fileLİst[i].fileName[0] != NULL)
                {
                    int sayac = 0;
                    for (int j = 0; j < sizeof(filename) / sizeof(filename[0]); j++)
                    {
                        if (c_fileLİst[i].fileName[j] == filename[j])
                        {
                            sayac++;
                        }
                    }
                    if (sayac == sizeof(filename) / sizeof(filename[0]))
                    {

                        printf("fFile mevcuttur.");
                        break;
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                if (c_fileLİst[i].fileName[0] == NULL)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        c_fileLİst[i].fileName[j] = filename[j];
                    }

                    break;
                }
            }

            // struct'i pipe ile yollar. Karsi tarafa.
            fd = open(myfifo, O_WRONLY);
            write(fd, &c_fileLİst, strlen(c_fileLİst) + 1);
            close(fd);
        }
        // Write ise write'a uygun bilgileri alir manager'da okur.
        else if (strcmp("WRITE", (str)) == 0)
        {

            fd = open(myfifo, O_WRONLY);
            write(fd, str, strlen(str) + 1);
            close(fd);

            printf("\n");
            printf("Filename yaziniz :");
            gets(filename);
            // alinani pipe'a yazar.
            fd = open(myfifo, O_WRONLY);
            write(fd, filename, strlen(filename) + 1);
            close(fd);

            printf("\n");
            printf("Lutfen dosyaya yazilacak metini yaziniz.. : ");
            gets(gelentext);

            fd = open(myfifo, O_WRONLY);
            write(fd, gelentext, strlen(gelentext) + 1);
            close(fd);
        }
        // read icin gereken kisimlari alir gonderir.
        else if (strcmp("READ", (str)) == 0)
        {
            fd = open(myfifo, O_WRONLY);
            write(fd, str, strlen(str) + 1);
            close(fd);

            printf("\n");
            printf("Lutfen okunacak fileName giriniz : ");
            gets(filename);

            fd = open(myfifo, O_WRONLY);
            write(fd, filename, strlen(filename) + 1);
            close(fd);
        }
        // adelete kisminin kontrollerini yapar
        else if (strcmp("DELETE", (str)) == 0)
        {
            fd = open(myfifo, O_WRONLY);
            write(fd, str, strlen(str) + 1);
            close(fd);

            printf("\n");
            printf("Lutfen silinecek fileName giriniz : ");
            gets(filename);
            // alinani pipe'a yazar.
            fd = open(myfifo, O_WRONLY);
            write(fd, filename, strlen(filename) + 1);
            close(fd);
        }
        // hatali kisim varsa tekrar kullanicidan bilgileri ister.
        else
        {
            printf("Hatali giris yapildi. Tekrar giris yapiniz.\n\n\n");
        }
    }

    return 0;
}