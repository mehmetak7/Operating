
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

// dosya isimlerini tutar.
typedef struct sFileList
{
    char fileName[20];
} s_fl;

s_fl FileLists[10];

// delete fonksiyonunu yapar.dosyayi path'ten siler.
int DeleteFile(char *filename)
{

    char file_path[1024];                              // Dosya yolunu saklayacak dizi
    strcpy(file_path, "/home/vboxuser/Desktop/test/"); // ./ ile klasörün içinde bulunduğu klasörü belirtiyoruz
    strcat(file_path, filename);                       // Dosya ismini yola ekliyoruz
    strcat(file_path, ".txt");
    if (remove(file_path) == 0)
    { // Dosyayı siliyoruz
        printf("'%s' dosyasi basariyla silindi.\n", filename);
        return 0;
    }
    else
    {
        printf("'%s' dosyasi silinemedi.\n", filename);
        return 1;
    }
}

// read fonksiyonunu yapar. dosyayi okuyup ekrana yazar.
int ReadFile(char *filename)
{
    strcat(filename, ".txt");
    for (int i = 0; i < 10; i++)
    {
        if (FileLists[i].fileName[0] != NULL)
        {
            int sayac = 0;
            for (int j = 0; j < sizeof(filename) / sizeof(filename[0]); j++)
            {
                if (FileLists[i].fileName[j] == filename[j])
                {
                    sayac++;
                }
            }
            if (sayac == sizeof(filename) / sizeof(filename[0]))
            {
                FILE *ptr;
                char ch;
                ptr = fopen(filename, "r");
                if (NULL == ptr)
                {
                    printf("file can't be opened \n");
                }
                printf("-----Dosyadan Okunan Yazi-----\n");
                do
                {
                    ch = fgetc(ptr);
                    printf("%c", ch);

                } while (ch != EOF);
                fclose(ptr);
                return 0; // basarili sekilde dosyaya yazildi
            }
        }
    }

    return 1;
}

// create fonksiyonunu yapar.
int CreateFile(char *filename)
{
    printf("gelen file name %s  \n", filename);

    for (int i = 0; i < 10; i++)
    {
        if (FileLists[i].fileName[0] != NULL)
        {
            int sayac = 0;
            for (int j = 0; j < sizeof(filename) / sizeof(filename[0]); j++)
            {
                if (FileLists[i].fileName[j] == filename[j])
                {
                    sayac++;
                }
            }
            if (sayac == sizeof(filename) / sizeof(filename[0]))
            {
                return 0;
            }
        }
    }

    for (int i = 0; i < sizeof(filename) / sizeof(filename[0]); i++)
    {
        if (FileLists[i].fileName[0] == NULL)
        {
            for (int j = 0; j < sizeof(filename) / sizeof(filename[0]); j++)
            {
                FileLists[i].fileName[j] = filename[j];
            }
            FILE *fp;
            fp = fopen(strcat(FileLists[i].fileName, ".txt"), "w");
            fclose(fp);
            return 1;
        }
    }

    return 1;
}

// write fonksiyonunu yapar.dosyaya gelen text i yazar.
int WriteFile(char *filename, char *gelenText)
{
    strcat(filename, ".txt");
    for (int i = 0; i < 10; i++)
    {
        if (FileLists[i].fileName[0] != NULL)
        {
            int sayac = 0;
            for (int j = 0; j < sizeof(filename) / sizeof(filename[0]); j++)
            {
                if (FileLists[i].fileName[j] == filename[j])
                {
                    sayac++;
                }
            }

            if (sayac == sizeof(filename) / sizeof(filename[0]))
            {
                FILE *fptr;
                fptr = fopen(FileLists[i].fileName, "a+");
                if (fptr == NULL)
                {
                    printf("Error!");
                    exit(1);
                }
                fprintf(fptr, "%s \n", gelenText);
                fclose(fptr);

                return 0; // basarili sekilde dosyaya yazildi
            }
        }
    }

    return 1; // yazilmasi istenen dosya listede YOK.
}

int main()
{
    int fd1;
    char gelenText[100]; // write icin gelen text tutulur.
                         //  FIFO file path
    char *myfifo = "/tmp/myfifo";

    mkfifo(myfifo, 0666);

    while (1)
    {
        char str1[80] = "";     // pipe'dan okunan islemi tutar
        char filename[80] = ""; // pipe'dan okunan islem yapilacak dosya adini tutar.
        char gelenText[80] = "";

        // pipe islem tipi icin okuma yapar
        fd1 = open(myfifo, O_RDWR);
        read(fd1, str1, 80);
        close(fd1);
        printf("islem: %s\n", str1);

        // okunan islem create'se dosya olusturur yukaridaki createfile fonksiyonu ile birlikte.
        if (strcmp("CREATE", (str1)) == 0)
        {

            fd1 = open(myfifo, O_RDWR);
            read(fd1, filename, 80);
            close(fd1);
            printf("Gelen filename:: %s\n", filename);

            fd1 = open(myfifo, O_RDWR);
            read(fd1, &FileLists, strlen(FileLists) + 1);
            close(fd1);
            printf("doğru okunan struct = %s\n", FileLists[0].fileName);

            int kontrol = CreateFile(filename);

            if (kontrol == 1) // olustulacak dosya yoksa olusturur
            {
                printf("%s dosyasi yoktu ve basarili sekilde olusturuldu. \n", filename);
            }
            if (kontrol == 0) // olusturulacak dosya varsa
            {
                printf("olusturmak istediginiz dosya adinda bir dosya listede zaten mevcuttur...\n");
            }
        }
        // okunan islem rewrite isedosya olusturur yukaridaki createfile fonksiyonu ile birlikte.
        else if (strcmp("WRITE", (str1)) == 0)
        {

            fd1 = open(myfifo, O_RDWR);
            read(fd1, filename, 80);
            close(fd1);
            printf("Gelen filename:: %s\n", filename);

            fd1 = open(myfifo, O_RDWR);
            read(fd1, gelenText, 80);
            close(fd1);
            printf("Gelen text: %s\n", gelenText);

            int kontrol = WriteFile(filename, gelenText);
            if (kontrol == 0)
            {
                printf("Metin dosyaya yazildi\n");
            }
            if (kontrol == 1)
            {
                printf("Yazilmak istenen dosya mevcut değil\n");
            }
        }
        // okunan islem read ise dosya olusturur yukaridaki createfile fonksiyonu ile birlikte.
        else if (strcmp("READ", (str1)) == 0)
        {

            fd1 = open(myfifo, O_RDWR);
            read(fd1, filename, 80);
            close(fd1);
            printf("Gelen filename:: %s\n", filename);

            int kontrol = ReadFile(filename);

            if (kontrol == 0) // okunacak dosya varsa
            {
                printf("%s dosyasi okundu ve basarili sekilde ekrana yazildi.. \n", filename);
            }
            if (kontrol == 1) // olusturulacak dosya yoksa
            {
                printf("olusturmak istediginiz dosya adinda bir dosya listede zaten mevcuttur...\n");
            }
        }
        // okunan islem credelete ise dosya olusturur yukaridaki createfile fonksiyonu ile birlikte.
        else if (strcmp("DELETE", (str1)) == 0)
        {

            fd1 = open(myfifo, O_RDWR);
            read(fd1, filename, 80);
            close(fd1);
            printf("Gelen filename:: %s\n", filename);

            int kontrol = DeleteFile(filename);
            if (kontrol == 0)
            {
                printf("dosya basariyla silindi...");
            }
            if (kontrol == 1)
            {
                printf("aranan dosya yok\n");
            }
        }
    }

    return 0;
}